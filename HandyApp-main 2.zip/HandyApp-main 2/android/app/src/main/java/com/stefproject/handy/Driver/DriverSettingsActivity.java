package com.stefproject.handy.Driver;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.stefproject.handy.Objects.DriverObject;
import com.stefproject.handy.R;
import com.stefproject.handy.Utils.Utils;

import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.graphics.Bitmap.CompressFormat.JPEG;

/**
 * Activity that displays the settings to the Driver
 */
public class DriverSettingsActivity extends AppCompatActivity {


    private int GALLERY = 10, CAMERA = 11;
    private EditText mNameField, mPhoneField, mCarField, mLicense, mService, mEmiratesID, mIban;

    private ImageView mProfileImage;
    private Bitmap picbitmap;
    private DatabaseReference mDriverDatabase;

    private String userID;

    private Uri resultUri;

    DriverObject mDriver = new DriverObject();
// not needed but to be consistent
    private String firebaseContentURIString;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_settings);

        // for saving camera pic for upload


        mNameField = findViewById(R.id.name);
        mPhoneField = findViewById(R.id.phone);
        mCarField = findViewById(R.id.car);
        mLicense = findViewById(R.id.license);
        mEmiratesID = findViewById(R.id.emid);
        mEmiratesID.addTextChangedListener(new EmidFormatWatcher());
        mIban = findViewById(R.id.iban);
        mProfileImage = findViewById(R.id.profileImage);
        mService = findViewById(R.id.service);

        Button mConfirm = findViewById(R.id.confirm);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        userID = mAuth.getCurrentUser().getUid();
        mDriverDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Drivers").child(userID);

        getUserInfo();

        mProfileImage.setOnClickListener(v -> {
//            Intent intent = new Intent(Intent.ACTION_PICK);
//            intent.setType("image/*");
//            startActivityForResult(intent, 1);
            showPictureDialog();
        });

        mService.setOnClickListener(view -> {
            Intent i = new Intent(DriverSettingsActivity.this, DriverChooseTypeActivity.class);
            i.putExtra("service", mDriver.getService());
            startActivityForResult(i, 2);
        });
        mConfirm.setOnClickListener(v -> saveUserInformation());
        setupToolbar();
    }

    /**
     * Sets up toolbar with custom text and a listener
     * to go back to the previous activity
     */
    private void setupToolbar() {
        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle(getString(R.string.settings));
        myToolbar.setTitleTextColor(getResources().getColor(R.color.white));
        ActionBar ab = getSupportActionBar();
        assert ab != null;
        ab.setDisplayHomeAsUpEnabled(true);
        myToolbar.setNavigationOnClickListener(v -> finish());
    }


    /**
     * Fetches current user's info and populates the design elements
     */
    private void getUserInfo(){
        mDriverDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    return;
                }
                mDriver.parseData(dataSnapshot);
                mNameField.setText(mDriver.getName());
                mPhoneField.setText(mDriver.getPhone());
                mCarField.setText(mDriver.getCar());
                mLicense.setText(mDriver.getLicense());
                mEmiratesID.setText(mDriver.getEmid());
                mService.setText(Utils.getTypeById(DriverSettingsActivity.this, mDriver.getService()).getName());
                mIban.setText(mDriver.getIban());

                if (!mDriver.getProfileImage().equals("default"))
                    Glide.with(getApplication()).load(mDriver.getProfileImage()).apply(RequestOptions.circleCropTransform()).into(mProfileImage);
            }

            @Override
            public void onCancelled(@NotNull DatabaseError databaseError) {
            }
        });
    }



    /**
     * Saves current user 's info to the database.
     * If the resultUri is not null that means the profile image has been changed
     * and we need to upload it to the storage system and update the database with the new url
     */
    private void saveUserInformation() {
        String name = mNameField.getText().toString();
        String phone = mPhoneField.getText().toString();
        String car = mCarField.getText().toString();
        String license = mLicense.getText().toString();
        String service = mDriver.getService();
        String emid = mEmiratesID.getText().toString();
        String iban = mIban.getText().toString();

        Map<String, Object> userInfo = new HashMap<String, Object>();
        userInfo.put("name", name);
        userInfo.put("phone", phone);
        userInfo.put("car", car);
        userInfo.put("license", license);
        userInfo.put("emid", emid);
        userInfo.put("service", service);
        userInfo.put("iban", iban);

        mDriverDatabase.updateChildren(userInfo);

        if(resultUri != null) {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading image...");
            progressDialog.show();
            Toast toast = Toast.makeText(getApplicationContext(), "uploading", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
            final StorageReference filePath = FirebaseStorage.getInstance().getReference().child("profile_images").child(userID);

            UploadTask uploadTask = filePath.putFile(resultUri);
            uploadTask.addOnFailureListener(e -> {
                finish();
            });
            uploadTask.addOnSuccessListener(taskSnapshot -> filePath.getDownloadUrl().addOnSuccessListener(uri -> {
                Map newImage = new HashMap();
                newImage.put("profileImageUrl", uri.toString());
                mDriverDatabase.updateChildren(newImage);
                progressDialog.dismiss();
                finish();
            }).addOnFailureListener(exception -> {
                progressDialog.dismiss();
                finish();
            }));
        }else{
            finish();
        }

    }

    // pictures - my code!
    private void showPictureDialog(){
        requestMultiplePermissions();
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallery();
                                break;
                            case 1:
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    public void choosePhotoFromGallery() {
        // temporary for testing
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    private void requestMultiplePermissions(){
        Dexter.withActivity(this)
                .withPermissions(
                        Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            //Toast.makeText(getApplicationContext(), "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            //openSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    private Uri getImageUri(Bitmap bitmap) throws IOException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        bitmap.compress(JPEG, 80, os);
        String path = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "file", null);
        // catch errors?
        Uri TheUri = Uri.parse(path);
        return TheUri;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == Activity.RESULT_OK){
            resultUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), resultUri);
                Glide.with(getApplication())
                        .load(resultUri) // Uri of the picture
                        .apply(RequestOptions.circleCropTransform())
                        .into(mProfileImage);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(requestCode == 2 && resultCode == Activity.RESULT_OK){
            String result= data.getStringExtra("result");
            mDriver.setService(result);
            mService.setText(Utils.getTypeById(DriverSettingsActivity.this, result).getName());
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                resultUri = data.getData();
                try {
                    //useless code
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), resultUri);
                    Glide.with(getApplication())
                            .asBitmap()
                            .apply(RequestOptions.circleCropTransform())
                            .load(bitmap)
                            .into(mProfileImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return;

        } else if (requestCode == CAMERA) {
            // thumbnail
            picbitmap = (Bitmap) data.getExtras().get("data");
            Glide.with(getApplication())
                    .asBitmap()
                    .apply(RequestOptions.circleCropTransform())
                    .load(picbitmap)
                    .into(mProfileImage);
            try {
                resultUri = getImageUri(picbitmap);
            }
            catch  (IOException e) {
                Toast toast = Toast.makeText(getApplicationContext(), "Failed, IO exception", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                e.printStackTrace();
            }
            return;
        }
    }
    /**
     * Formats the watched EditText to an emirates ID
     */
    public class EmidFormatWatcher implements TextWatcher {

        // Change this to what you want... ' ', '-' etc..
        private static final char space = '-';
        private int prev;
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            prev = s.length();
        }

        @Override
        public void afterTextChanged(Editable s) {

            if (s.length() > 0 && s.length()>prev) {
                final char c = s.charAt(s.length() - 1);
                // only allow digits
                if (s.length() == 19) {
                    s.delete(s.length() -1, s.length());
                }
                if (s.length() == 3) {
                    // Only if its a digit where there should be a space we insert a space
                    if (Character.isDigit(c)) {
//                    if (Character.isDigit(c) && TextUtils.split(s.toString(), String.valueOf(space)).length <= 3) {
                        s.append(String.valueOf(space));
                    }
                }
                if (s.length() == 8) {
                    // Only if its a digit where there should be a space we insert a space
                    if (Character.isDigit(c) && TextUtils.split(s.toString(), String.valueOf(space)).length <= 3) {
                        s.append(String.valueOf(space));
                    }
                }
                if (s.length() == 16) {
                    // Only if its a digit where there should be a space we insert a space
                    if (Character.isDigit(c) && TextUtils.split(s.toString(), String.valueOf(space)).length <= 3) {
                        s.append(String.valueOf(space));
                    }
                }
            }
            if (s.length() > 0 && s.length()<prev) {
            // Remove spacing char
                final char c = s.charAt(s.length() - 1);
                if (space == c) {
                    s.delete(s.length() - 1, s.length());
                }
            }



        }
    }

}
