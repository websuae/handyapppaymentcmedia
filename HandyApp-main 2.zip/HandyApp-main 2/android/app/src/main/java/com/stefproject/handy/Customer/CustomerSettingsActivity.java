package com.stefproject.handy.Customer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.stefproject.handy.Objects.CustomerObject;
import com.stefproject.handy.R;

import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.graphics.Bitmap.CompressFormat.JPEG;
import static com.bumptech.glide.request.RequestOptions.circleCropTransform;


/**
 * Activity that displays the settings to the customer
 */
public class CustomerSettingsActivity extends AppCompatActivity {

    private int GALLERY = 10, CAMERA = 11;
    private static final String TAG = "tag";
    private EditText mNameField, mPhoneField;
    private Bitmap picbitmap;
    private ImageView mProfileImage;
    private DatabaseReference mCustomerDatabase;

    // not needed but to be consistent
    private String firebaseContentURIString;
    private String userID;

    private Uri resultUri;

    CustomerObject mCustomer;

    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_settings);

        mNameField = findViewById(R.id.name);
        mPhoneField = findViewById(R.id.phone);

        mProfileImage = findViewById(R.id.profileImage);

        Button mConfirm = findViewById(R.id.confirm);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        userID = mAuth.getCurrentUser().getUid();
        mCustomerDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Customers").child(userID);

        mCustomer = new CustomerObject(userID);

        getUserInfo();

        mProfileImage.setOnClickListener(v -> {
//            Intent intent = new Intent(Intent.ACTION_PICK);
//            intent.setType("image/*");
//            startActivityForResult(intent, 1);
            showPictureDialog();
        });

        mConfirm.setOnClickListener(v -> saveUserInformation());


        setupToolbar();
    }

    /**
     * Sets up toolbar with custom text and a listener
     * to go back to the previous activity
     */
    private void setupToolbar() {
        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle(getString(R.string.settings));
        myToolbar.setTitleTextColor(getResources().getColor(R.color.white));
        ActionBar ab = getSupportActionBar();
        assert ab != null;
        ab.setDisplayHomeAsUpEnabled(true);
        myToolbar.setNavigationOnClickListener(v -> finish());
    }

    /**
     * Fetches current user's info and populates the design elements
     */
    private void getUserInfo(){
        mCustomerDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()){return;}

                mCustomer.parseData(dataSnapshot);

                mNameField.setText(mCustomer.getName());
                mPhoneField.setText(mCustomer.getPhone());
                checkIfPhoneIsAdded();

                if(!mCustomer.getProfileImage().equals("default"))
                    Glide.with(getApplication()).load(mCustomer.getProfileImage()).apply(circleCropTransform()).into(mProfileImage);

            }

            @Override
            public void onCancelled(@NotNull DatabaseError databaseError) {
            }
        });
    }


    /**
     * Saves current user 's info to the database.
     * If the resultUri is not null that means the profile image has been changed
     * and we need to upload it to the storage system and update the database with the new url
     */
    private void saveUserInformation() {
        String mName = mNameField.getText().toString();
        String mPhone = mPhoneField.getText().toString();

        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("name", mName);
        userInfo.put("phone", mPhone);
        Toast.makeText(getApplicationContext(), "Information saved successfully", Toast.LENGTH_SHORT).show();
        mCustomerDatabase.updateChildren(userInfo);

        if(resultUri != null) {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading image...");
            progressDialog.show();
            final StorageReference filePath = FirebaseStorage.getInstance().getReference().child("profile_images").child(userID);
            UploadTask uploadTask = filePath.putFile(resultUri);

            uploadTask.addOnFailureListener(e -> {
                finish();
            });
            uploadTask.addOnSuccessListener(taskSnapshot -> filePath.getDownloadUrl().addOnSuccessListener(uri -> {
                Map newImage = new HashMap();
                newImage.put("profileImageUrl", uri.toString());
                mCustomerDatabase.updateChildren(newImage);
                progressDialog.dismiss();
                finish();
            }).addOnFailureListener(exception -> {
                progressDialog.dismiss();
                finish();
            }));

        }else{
            finish();
        }

    }

    private void checkIfPhoneIsAdded(){
        if (mPhoneField.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please add a phone number so the transporter can contact you for further instructions", Toast.LENGTH_SHORT).show();
        }
    }

    // pictures - my code!
    private void showPictureDialog(){
        requestMultiplePermissions();
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallery();
                                break;
                            case 1:
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    public void choosePhotoFromGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    private void requestMultiplePermissions(){
        Dexter.withActivity(this)
                .withPermissions(
                        Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            //Toast.makeText(getApplicationContext(), "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            //openSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    private Uri getImageUri(Bitmap bitmap) throws IOException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        bitmap.compress(JPEG, 80, os);
        String path = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "file", null);
        // catch errors?
        Uri TheUri = Uri.parse(path);
        return TheUri;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            resultUri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), resultUri);
                RequestOptions myOptions = new RequestOptions()
                        .override(100, 100)
                        .circleCropTransform();
                Glide.with(getApplication())
                        .load(resultUri)
                        .apply(myOptions)
                        .into(mProfileImage);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                resultUri = data.getData();
                try {
                    //useless code
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), resultUri);
                    Glide.with(getApplication())
                            .asBitmap()
                            .apply(RequestOptions.circleCropTransform())
                            .load(bitmap)
                            .into(mProfileImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return;


        } else if (requestCode == CAMERA) {
            // thumbnail
            picbitmap = (Bitmap) data.getExtras().get("data");
            Glide.with(getApplication())
                    .asBitmap()
                    .apply(RequestOptions.circleCropTransform())
                    .load(picbitmap)
                    .into(mProfileImage);
            try {
                resultUri = getImageUri(picbitmap);
            } catch (IOException e) {
                Toast toast = Toast.makeText(getApplicationContext(), "Failed, IO exception", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                e.printStackTrace();
            }
            return;
        }
    }
}
