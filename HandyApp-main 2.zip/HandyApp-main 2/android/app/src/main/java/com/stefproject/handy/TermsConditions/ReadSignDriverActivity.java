package com.stefproject.handy.TermsConditions;

import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.ScrollingMovementMethod;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.stefproject.handy.Objects.DriverObject;
import com.stefproject.handy.R;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class ReadSignDriverActivity extends AppCompatActivity {

    private EditText mNameField;
    private DatabaseReference mDriverDatabase;
    private String userID;
    private String name;

    DriverObject mDriver = new DriverObject();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_readandsign_driver);

        mNameField = findViewById(R.id.name);

        Button mAccept = findViewById(R.id.accept_button);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        userID = mAuth.getCurrentUser().getUid();
        mDriverDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Drivers").child(userID);

        getUserInfo();
        mAccept.setOnClickListener(v -> saveUserInformation());

        setupToolbar();
        setupTC();
    }

    /**
     * All we want is his name
     */
    private void getUserInfo(){
        mDriverDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.exists()) {
                    return;
                }
                mDriver.parseData(dataSnapshot);
                name = mDriver.getName();
            }

            @Override
            public void onCancelled(@NotNull DatabaseError databaseError) {
            }
        });
    }

    private void saveUserInformation() {
        String filledName = mNameField.getText().toString();

        Map<String, Object> userInfo = new HashMap<String, Object>();

        if (name.contains(filledName) || filledName.contains(name) ) {
            userInfo.put("readAndSignDone", true);
            userInfo.put("activated", true);
            mDriverDatabase.updateChildren(userInfo);
            finish();
            Toast.makeText(getApplicationContext(), "Read and Sign done successfully, account has been activated", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Name did not match the name you signed up with, please try again", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Sets up toolbar with custom text and a listener
     * to go back to the previous activity
     */
    private void setupToolbar() {
        Toolbar myToolbar = findViewById(R.id.tc_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle(getString(R.string.read_and_sign));
        myToolbar.setTitleTextColor(getResources().getColor(R.color.white));
        ActionBar ab = getSupportActionBar();
        assert ab != null;
        ab.setDisplayHomeAsUpEnabled(true);
        myToolbar.setNavigationOnClickListener(v -> finish());
    }

    private void setupTC() {
        TextView RS = findViewById(R.id.tc_text);
        RS.setMovementMethod(new ScrollingMovementMethod());
        Spanned sp = Html.fromHtml( getString(R.string.read_and_sign_drivers_full_text));
        RS.setText(sp);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
