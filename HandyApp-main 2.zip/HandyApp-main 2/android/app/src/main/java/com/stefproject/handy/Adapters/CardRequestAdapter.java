package com.stefproject.handy.Adapters;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.stefproject.handy.Objects.RideObject;
import com.stefproject.handy.R;

import java.util.List;

/**
 * Adapter responsible for handling the display of the Cards to the user
 */
public class CardRequestAdapter extends ArrayAdapter<RideObject>{

    int TIMEOUT_MILLISECONDS = 300000; //5min
//    int TIMEOUT_MILLISECONDS = 10000; //10sec

    private double TAXI_CUT = 0.8;
    Context context;
    List<RideObject> items;

    public CardRequestAdapter(Context context, int resourceId, List<RideObject> items){
        super(context, resourceId, items);
        this.context = context;
        this.items = items;
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Controller");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NotNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    TAXI_CUT =  1 - Double.parseDouble(dataSnapshot.child("handy_margin").getValue().toString());
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

    }

    /**
     * Populate the item_message with user in the current position
     *
     * Changes the message aspect if it is from the current user or the match
     *
     * @param position - position of the list
     */
    public View getView(int position, View convertView, ViewGroup parent){
        RideObject card_item = getItem(position);

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item__card_request, parent, false);
        }

        TextView mPickup = convertView.findViewById(R.id.pickup);
        TextView mDropoff = convertView.findViewById(R.id.dropoff);

        TextView mDistance = convertView.findViewById(R.id.distance);
        TextView mTime = convertView.findViewById(R.id.time);
        TextView mAssistance = convertView.findViewById(R.id.assistance);
        TextView mFee = convertView.findViewById(R.id.estimated_fee_driver);
        ImageView mGoods =  convertView.findViewById(R.id.goods);


        CircularProgressBar mProgressBar = convertView.findViewById(R.id.circularProgressBar);



        if (card_item != null) {
            mDistance.setText(card_item.getCalculatedRideDistance());
            mPickup.setText("Pickup location:\n" + card_item.getPickupName());
            mDropoff.setText("Drop-off location:\n" + card_item.getDestinationName());
        }
        if (card_item != null) {
            int time = 2;
            int calctime = card_item.getCalculatedTime();
            if (calctime > 2) {
                time = calctime;
            }
            mTime.setText(time + " min");
        }

        if (card_item != null) {
            if (card_item.getRequestService().contains("1")){
                mAssistance.setText("1 person assistance needed");
            }
            else if (card_item.getRequestService().contains("2")){
                mAssistance.setText("2 person assistance needed");
            }
            else {
                mAssistance.setText("No assistance needed");
            }
        }

        if (card_item != null) {
            String feeValue = "0";
            if(card_item.getRequestService().contains("1")) {
                feeValue = getPriceBracket((int) (((double)card_item.getEstimate1p())*TAXI_CUT));
            }
            if(card_item.getRequestService().contains("2")) {
                feeValue = getPriceBracket((int) (((double)card_item.getEstimate2p())*TAXI_CUT));
            }
            mFee.setText("Estimated fee is AED " + feeValue);
        }

        if (card_item != null) {
            Glide.with(convertView)
                    .load(card_item.getImageUrl())
                    // temporary for testing
//                    .load("https://firebasestorage.googleapis.com/v0/b/mover-ea9cb.appspot.com/o/profile_images%2FhPgoHiL1PFfNit5PQ8vmFjGTCgn1?alt=media&token=2a5a21a9-064c-437f-95b6-097e178cf4a3")
                    .centerCrop()
                    .placeholder(R.drawable.wait_icon)
                    .error(R.drawable.ic_cancel_black_24dp)
////                .fallback(R.drawable.ic_no_image)
                    .into(mGoods);
        }
        final Handler ha=new Handler();
        ha.postDelayed(new Runnable() {

            @Override
            public void run() {
                //call function
                if (card_item != null) {
                    if (card_item.getTimePassed()==0) {
                        //need to start with the time that has already passed since customer posted the request
                        float passed = card_item.getServerTimePassed();
                        float passed2 = passed/525;
                        card_item.setTimePassed(passed2 + (float)0.05);

                    }
                    else {
                        card_item.setTimePassed(card_item.getTimePassed() + (float)0.05);
                    }
                }
                if (card_item != null) {
                    mProgressBar.setProgress(card_item.getTimePassed()/TIMEOUT_MILLISECONDS*52500);
                    //mAssistance.setText(String.valueOf(card_item.getTimePassed()/TIMEOUT_MILLISECONDS*52500));
                }

                if (card_item != null && card_item.getTimePassed() > TIMEOUT_MILLISECONDS) {
                    //this doesn't work, because getTimePassed() is not showing milliseconds!
                    items.remove(card_item);
                    notifyDataSetChanged();
                }

                ha.postDelayed(this, 25);

            }
        }, 25);

        return convertView;
    }

    private String getPriceBracket(int estimate) {
        int bottomEst = estimate - 5 - (estimate%5);
        int topEst = estimate + 10 - (estimate%5);
        return (String.valueOf(bottomEst) + " - " + String.valueOf(topEst));
    }
}
