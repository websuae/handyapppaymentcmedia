package com.stefproject.handy.TermsConditions;

import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.stefproject.handy.R;

public class TermsConditionsCustomerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_termsconditions_customer);

        setupToolbar();
        setupTC();
    }

    /**
     * Sets up toolbar with custom text and a listener
     * to go back to the previous activity
     */
    private void setupToolbar() {
        Toolbar myToolbar = findViewById(R.id.tc_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle(getString(R.string.terms_conditions));
        myToolbar.setTitleTextColor(getResources().getColor(R.color.white));
        ActionBar ab = getSupportActionBar();
        assert ab != null;
        ab.setDisplayHomeAsUpEnabled(true);
        myToolbar.setNavigationOnClickListener(v -> finish());
    }

    private void setupTC() {
        TextView myTC = findViewById(R.id.tc_text);
        myTC.setMovementMethod(new ScrollingMovementMethod());
        Spanned sp = Html.fromHtml( getString(R.string.terms_conditions_full));
        myTC.setText(sp);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
